document.addEventListener('DOMContentLoaded', (event) => {
    console.log('Le document est entièrement chargé et analysé');
});
